const parentMenu = document.querySelectorAll("._has-child > a");
for (let i = 0; i < parentMenu.length; i++) {
  parentMenu[i].addEventListener("click", function (e) {
    e.preventDefault();
    this.nextElementSibling.classList.toggle("active");
  });
}


const menuButton = document.querySelector(".menu-btn");
const navBar = document.querySelector("#MobileMenu");
menuButton.addEventListener("click", () => {
  if (!menuButton.classList.contains("nav-close")) {
    menuButton.classList.add("nav-close");
    navBar.classList.add("on-nav");
  } else {
    menuButton.classList.remove("nav-close");
    navBar.classList.remove("on-nav");
  }
});


const getActiveMap = function (e, id) {
  const clickElemnt = document.querySelectorAll(".map-title");
  const targetElemnt = document.querySelectorAll(".map-target-content");
  targetElemnt.forEach((data) => {
    data.classList.remove("active");
  });
  clickElemnt.forEach((data) => {
    data.classList.remove("active");
  });
  targetElemnt[id - 1].classList.add("active");
  e.target.classList.add("active");
};

function getActiveAbout(element, tab) {
  const tabs = document.querySelectorAll('#tabs a');
  tabs.forEach(tab => {
    tab.classList.remove('li-active');
  });
  element.classList.add('li-active');
}

function largeImage(imageSrc) {
  console.log(imageSrc);
  document.getElementById("gallery-popup-img").src = imageSrc;
  document.getElementById("gallery-popup").style.display = "flex";
}

function closeImage() {
  document.getElementById("gallery-popup").style.display = "none";
}


