const parentMenu = document.querySelectorAll("._has-child > a");
for (let i = 0; i < parentMenu.length; i++) {
  parentMenu[i].addEventListener("click", function (e) {
    e.preventDefault();
    this.nextElementSibling.classList.toggle("active");
  });
}


const menuButton = document.querySelector(".menu-btn");
const navBar = document.querySelector("#MobileMenu");
menuButton.addEventListener("click", () => {
  if (!menuButton.classList.contains("nav-close")) {
    menuButton.classList.add("nav-close");
    navBar.classList.add("on-nav");
  } else {
    menuButton.classList.remove("nav-close");
    navBar.classList.remove("on-nav");
  }
});


const getActiveMap = function (e, id) {
  const clickElemnt = document.querySelectorAll(".map-title");
  const targetElemnt = document.querySelectorAll(".map-target-content");
  targetElemnt.forEach((data) => {
    data.classList.remove("active");
  });
  clickElemnt.forEach((data) => {
    data.classList.remove("active");
  });
  targetElemnt[id - 1].classList.add("active");
  e.target.classList.add("active");
};

function getActiveAbout(element, tab) {
  const tabs = document.querySelectorAll('#tabs a');
  tabs.forEach(tab => {
    tab.classList.remove('li-active');
  });
  element.classList.add('li-active');
}

function largeImage(imageSrc) {
  console.log(imageSrc);
  document.getElementById("gallery-popup-img").src = imageSrc;
  document.getElementById("gallery-popup").style.display = "flex";
}

function closeImage() {
  document.getElementById("gallery-popup").style.display = "none";
}



function enlargeImage(imageId) {
  var imgSrc = document.getElementById(imageId).getAttribute("src");
  document.getElementById("enlarged-image").setAttribute("src", imgSrc);
  document.querySelector(".enlarged").classList.add("active");
}

function closeEnlarged() {
  document.querySelector(".enlarged").classList.remove("active");
}

window.addEventListener("scroll", function () {
  var fnavbar = document.getElementById("fixed-navbar");
  if(fnavbar !== null){
    if (window.pageYOffset > 0) {
      fnavbar.style.display = "block";
    } else {
      fnavbar.style.display = "none";
    }
  }
});
if(page=='contactus'){
  $(document).ready(function() {
    $('#submit').on('click', function() {
        // Validate form fields
        var isValid = true;
        $('#sendfeedback input, #sendfeedback select, #sendfeedback textarea').each(function() {
            if ($(this).val() === '') {
                isValid = false;
                $(this).css('border', '1px solid red');
            } else {
                $(this).css('border', ''); 
            }
        });
        if (!isValid) {
          alert('Please fill out all fields.');
          return;
      }
        var email = $('#email').val();
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            isValid = false;
            $('#email').css('border', '1px solid red');
            alert("Please Enter Valid email");
            return;
        } else {
            $('#email').css('border', '');
        }

        // Mobile number validation
        var mobile = $('#phone').val();
        var mobileRegex = /^[0-9]{10}$/;
        if (!mobileRegex.test(mobile)) {
            isValid = false;
            $('#phone').css('border', '1px solid red');
            alert("Please Enter Valid phone number");
            return;
        } else {
            $('#phone').css('border', '');
        }
        

        // Serialize form data
        var formData = $('#sendfeedback').serialize();

        // Submit form data via AJAX
        $.ajax({
            type: 'POST',
            url: baseurl+'utility/feedback_submit.php?fun=submitfeedback',
            data: formData,
            success: function(response) {
              $('#sendfeedback input, #sendfeedback select, #sendfeedback textarea').each(function() {
                if($(this).attr("type")!=='button'){
                  $(this).val("");
                }
            });
                // Optionally handle success here
              alert('Your message has been sent successfully.');
            },
            error: function(error) {
                console.error('Error:', error);
                // Optionally handle error here
                alert('There was an error submitting your message.');
            }
        });
    });
});
}
if(page=='aboutus' || page=='home'){
	const counters = document.querySelectorAll('.num');
	const speed = 200;
	counters.forEach( counter => {
	const animate = () => {
          const value = +counter.getAttribute('data-count');
          const data = +counter.innerText;

          const time = value / speed;
          if(data < value) {
            counter.innerText = Math.ceil(data + time);
            setTimeout(animate, 1);
          }else{
            counter.innerText = value;
          }
        }
        animate();
      });
}
  //================Page wise Js Start====================
  if(page =='Courses'){
  const questions = document.querySelectorAll(".block-heading");
    const answers = document.querySelectorAll(".faq-content");

    questions[0].classList.add("active");
    answers[0].classList.add("active");

    questions.forEach((question, index) => {
      question.addEventListener("click", () => {
        questions.forEach((question) => {
          question.classList.remove("active");
        });
        question.classList.add("active");
        answers.forEach((answer) => {
          if (answer.previousElementSibling === question) {
            answer.classList.add("active");
          } else {
            answer.classList.remove("active");
          }
        });
      });
    });

    window.addEventListener('load', function() {
      var targetElement = document.getElementById('courses-list-div');
      if (targetElement) {
          setTimeout(function() {
            targetElement.scrollIntoView({ behavior: 'smooth' });
        }, 500);
      }
  });



  }
 //================Page wise Js End====================


