<?php
#print_r($_REQUEST);die;
require_once '/home3/indiamart/public_html/flapone/includes/config.php';
require_once ('/home3/indiamart/public_html/flapone/includes/functions.php');

$articleArray=array(
    "blog"=>"blog",
    "awards-recognitions"=>"awards",
    "success-stories"=>"stories",
 );

$article_type = $articleArray[$_REQUEST['blog_type']];

require_once ('/home/indiamart/public_html/flapone/modules/blog_detail_module.php');

$full_path_to_public_program = "/home/indiamart/public_html/flapone";
require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();

require_once ('/home/indiamart/public_html/flapone/modules/header.php');
$blogData=checkBlogUrl($article_type);

$parentCategoryList = getParentCategoryList();
$breadcrumbData = getBreadcrumbData($blogData,$article_type);
$locationList=getLocationData('footer');
$gallaryImages=getPageWiseImageAll($blogData['id'],"article");
$similarbloglist=getSimilarBlogList($article_type);
$getaward = getourAward(6);
$courseList=getSimilarCourseList("","","");

$sublogData=getSubBlogList($blogData['id']);

$pageOtherData=getpageOtherData($blogData);

$relatedArticle=getArticleData(6,$article_type);

$smarty_obj->assign('BASEURL', BASEURL);
$smarty_obj->assign('MEDIA_URL', MEDIA_URL);
$smarty_obj->assign('page', "blog_detail");
$smarty_obj->assign('coursebg', "dark");

$smarty_obj->assign('pagetitle', $blogData['title']);
$smarty_obj->assign("pagestatus",$blogData['status']);

$smarty_obj->assign("sliderimage",$gallaryImages['allimage']);

$smarty_obj->assign("mainBlog",$blogData);
$smarty_obj->assign("subBlog",$sublogData);

if(!empty($pageOtherData['meta_keywords'])){
$smarty_obj->assign("meta_title",isset($pageOtherData['meta_keywords'][0]['meta_title'])?$pageOtherData['meta_keywords'][0]['meta_title']:"");
$smarty_obj->assign("meta_description",isset($pageOtherData['meta_keywords'][1]['meta_desc'])?$pageOtherData['meta_keywords'][1]['meta_desc']:"");
$smarty_obj->assign("meta_keywords",isset($pageOtherData['meta_keywords'][2]['meta_keywords'])?$pageOtherData['meta_keywords'][2]['meta_keywords']:"");
}

$smarty_obj->assign("coverimage",$gallaryImages['cover_image']);
$smarty_obj->assign('breadcrumbData', $breadcrumbData);
$smarty_obj->assign('parentCategoryList', $parentCategoryList);
$smarty_obj->assign('faqlist', $faqList);
$smarty_obj->assign('locationlist', $locationList);
$smarty_obj->assign('simbloglist', $similarbloglist);
$smarty_obj->assign('courselist', $courseList);
$smarty_obj->assign('awarddata', $getaward);
$smarty_obj->assign('gallayimages', $gallaryImages['allimage']);

 $smarty_obj->assign('articleresult', array("title"=>ucwords($article_type),"subtitle"=>"Related ". ucwords($article_type),"viewallurl"=>"","data"=>$relatedArticle,"bgcolor"=>"dark"));

$smarty_obj->display('common/header.tpl');
$smarty_obj->display('blog_detail.tpl');
$smarty_obj->display('common/footer.tpl');

?>