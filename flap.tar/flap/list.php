<?php

require_once ('/home3/indiamart/public_html/flapone/includes/config.php');
require_once ('/home3/indiamart/public_html/flapone/includes/functions.php');
require_once ('/home3/indiamart/public_html/flapone/modules/list_module.php');
$full_path_to_public_program = "/home/indiamart/public_html/flapone";

require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();

require_once ('/home/indiamart/public_html/flapone/modules/header.php');

$parentCategoryList = getParentCategoryList();
$courseList = getCourseList('','');
$pageOtherData=getpageOtherData();
$faqList=getFaqData($pageOtherData['faq_type'],$pageOtherData['cat_id']);
$locationList=getLocationData('footer');
$getaward = getourAward(6);

$smarty_obj->assign('BASEURL', BASEURL);
$smarty_obj->assign('MEDIA_URL', MEDIA_URL);
$smarty_obj->assign('page', "Courses");
$smarty_obj->assign('coursebg', "");
$smarty_obj->assign('pagetitle', $pageOtherData['page_title']);
$smarty_obj->assign("coverimage",$pageOtherData['coverimage']);
$smarty_obj->assign("pagestatus",$pageOtherData['page_status']);
$smarty_obj->assign("category",$pageOtherData['category']);

if(!empty($pageOtherData['meta_keywords'])){
$smarty_obj->assign("meta_title",isset($pageOtherData['meta_keywords'][0]['meta_title'])?$pageOtherData['meta_keywords'][0]['meta_title']:"");
$smarty_obj->assign("meta_description",isset($pageOtherData['meta_keywords'][1]['meta_desc'])?$pageOtherData['meta_keywords'][1]['meta_desc']:"");
$smarty_obj->assign("meta_keywords",isset($pageOtherData['meta_keywords'][2]['meta_keywords'])?$pageOtherData['meta_keywords'][2]['meta_keywords']:"");
}

$smarty_obj->assign("offset_auto",$courseList['offset_auto']);
$smarty_obj->assign("row_per_page",$courseList['row_per_page']);
$smarty_obj->assign('courselist', $courseList['courses']);

$smarty_obj->assign('awarddata', $getaward);

$smarty_obj->assign('breadcrumbData', array(array('title'=>$pageOtherData['page_title'])));
$smarty_obj->assign('parentCategoryList', $parentCategoryList);
$smarty_obj->assign('faqlist', $faqList);
$smarty_obj->assign('locationlist', $locationList);

$smarty_obj->display('common/header.tpl');
$smarty_obj->display('list.tpl');
$smarty_obj->display('common/footer.tpl');
$smarty_obj->display('otherjs/listjs.tpl');

?>