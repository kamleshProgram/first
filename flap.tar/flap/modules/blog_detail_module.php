<?php
function checkBlogUrl($article_type){

  $return_data=array();

  $blog_url=$_REQUEST['blogurl'];
  $blogChkUrlQuery="SELECT * FROM flapone_articles WHERE article_url='$blog_url' AND article_type='$article_type'  AND status='1' LIMIT 1";

 
  $blogChkUrlSql = selectSqLQuery($blogChkUrlQuery);
  if(mysqli_num_rows($blogChkUrlSql) > 0){
          $rows = mysqli_fetch_assoc($blogChkUrlSql);
          $return_data = $rows;
    }else{
        
        echo "page not found";die;

    }

  return $return_data;
 }


 function getBreadcrumbData($blogData,$blog_type){
  $return_data=array();
  $return_data[0]['title']=ucwords($blog_type);
  $return_data[0]['url']=BASEURL.$_REQUEST['blog_type'];
  $return_data[1]['title']=$blogData['title'];
  $return_data[1]['url']="";
  return $return_data;
 }



 function getSubBlogList($blog_id){
  $response_array=array();
  $blogListQuery="SELECT * FROM flapone_articles where parent_id='$blog_id' AND status='1'";
 
  $blogListSql = selectSqLQuery($blogListQuery);
  if(mysqli_num_rows($blogListSql) > 0){
          $subblog_data=array();
          while($rows = mysqli_fetch_assoc($blogListSql)){
          
              $subblog_data['title'] = $rows['title'];
              $subblog_data['article_url'] = $rows['article_url'];
              $subblog_data['overview'] = $rows['overview'];
              $subblog_data['small_overview'] = $rows['small_overview'];
              $subBlogImage = getPageWiseImageAll($rows['id'],"article");
              $subblog_data['subBlogImages']=$subBlogImage;
              $return_data[] = $subblog_data;
          }   
  } 

  $response_array=$return_data;  
  return $response_array;
}


 function getSimilarBlogList($blog_type){
  $response_array=array();
  $blog_url=$blog_type;
  $blogListQuery="SELECT * FROM flapone_articles where status='1' AND article_type='$blog_url'";
 
  $blogListSql = selectSqLQuery($blogListQuery);
  if(mysqli_num_rows($blogListSql) > 0){
          $blog_data=array();
          while($rows = mysqli_fetch_assoc($blogListSql)){
              $blog_data['title'] = $rows['title'];
              $blog_data['article_url'] = $rows['article_url'];
              $blog_data['overview'] = $rows['overview'];
              $blog_data['small_overview'] = $rows['small_overview'];
              $return_data[] = $blog_data;
          }   
  } 

  $response_array=$return_data;  
  return $response_array;
}





function getpageOtherData($blogData){

  $return_data=array();
  $decode_pmeta_keywords='';
  if(isset($blogData['meta_keywords']) && !empty($blogData['meta_keywords'])){
           $decode_pmeta_keywords = json_decode($blogData['meta_keywords'],true);   
  }

  $return_data['meta_keywords']=$decode_pmeta_keywords;
  return $return_data;
}





?>