<?php
function checkCourseUrl(){
  $return_data=array();
  $course_url=$_REQUEST['course'];
  $courseChkUrlQuery="SELECT * FROM flapone_course WHERE course_url='$course_url' AND course_status='1' LIMIT 1 ";

  $courseChkUrlSql = selectSqLQuery($courseChkUrlQuery);
  if(mysqli_num_rows($courseChkUrlSql) > 0){
          $rows = mysqli_fetch_assoc($courseChkUrlSql);
          $return_data = $rows;
    }else{
        
        echo "page not found";die;

    }

  return $return_data;
 }


 function getpageOtherData($blogData){

  $return_data=array();
  $decode_pmeta_keywords='';
  if(isset($blogData['meta_keywords']) && !empty($blogData['meta_keywords'])){
           $decode_pmeta_keywords = json_decode($blogData['meta_keywords'],true);   
  }

  $return_data['meta_keywords']=$decode_pmeta_keywords;
  return $return_data;
}



 function getBreadcrumbData($categoryData,$courseData){
  $return_data=array();
  $parentCategoryData=getCatDeatil($categoryData['parent_category_id']);

  $return_data[0]['title']=$categoryData['category_name'];
  $return_data[0]['url']=BASEURL.$parentCategoryData['category_url']."/".$categoryData['category_url'];
  $return_data[1]['title']=$courseData['course_name'];
  $return_data[1]['url']="";

  return $return_data;
 }


 function getTeacherByCourse($course_id){
  $return_data=array();
  $teacherListQuery="SELECT instractor_id from flapone_couser_instractor_mapping where course_id='$course_id'";
  $teacherListSql = selectSqLQuery($teacherListQuery);
  if(mysqli_num_rows($teacherListSql) > 0){
    $instractor_data=array();
    while($rows = mysqli_fetch_assoc($teacherListSql))  {
        $instractor_data = $rows['instractor_id'];
       
        $return_data[] = $instractor_data;
    }   
  } 
  return $return_data;
 }
  

function getCourseDetail($courseData){
  
  $return_data=array();
  $return_data['course_eligibility']=$return_data['course_overview']=$return_data['course_price']=$return_data['course_highlights']=$return_data['course_highlights']=$return_data['meta_keywords']=array();

  $return_data['course_name']=$courseData['course_name'];
  $return_data['course_duration']=$courseData['course_duration'];

  if(isset($courseData['course_eligibility']) && $courseData['course_eligibility']!=''){
    $return_data['course_eligibility']=json_decode($courseData['course_eligibility'],true);
  }

  if(isset($courseData['course_overview']) && $courseData['course_overview']!=''){
    $return_data['course_overview']=json_decode($courseData['course_overview'],true);
  }

  if(isset($courseData['course_price']) && $courseData['course_price']){
    $course_price_detail = json_decode($courseData['course_price'],true);
    #print_r($course_price_detail);die;
    $country_code=='';
    if($country_code=='91' || $country_code==''){
        $return_data['course_price']['course_price'] = $course_price_detail['INR']['price'];
        $return_data['course_price']['tax_status'] = $course_price_detail['INR']['tax_status'];
        if(isset($course_price_detail['INR']['tax_status']) && !empty($course_price_detail['INR']['tax_status']) && $course_price_detail['INR']['tax_status']!="included"){
         $return_data['course_price']['net_price'] = $course_price_detail['INR']['price'] + (($course_price_detail['INR']['price'] * $course_price_detail['INR']['tax_status']) / 100);

        }else{
          $return_data['course_price']['net_price'] = $course_price_detail['INR']['price'];
        }

        $return_data['course_price']['discount'] = $course_price_detail['INR']['discount'];
        $return_data['course_price']['currency'] = "₹";
    }else{

        $return_data['course_price']['course_price'] = $course_price_detail['USD']['price'];
        $return_data['course_price']['tax_status'] = $course_price_detail['USD']['tax_status'];
        if(isset($course_price_detail['USD']['tax_status']) && !empty($course_price_detail['USD']['tax_status']) && $course_price_detail['USD']['tax_status']!="included"){
          $return_data['course_price']['net_price'] = $course_price_detail['USD']['price'] + ($course_price_detail['USD']['price'] * $course_price_detail['USD']['tax_status'] /100);
        }else{
          $return_data['course_price']['net_price'] = $course_price_detail['USD']['price'];
        }

        $return_data['course_price']['discount'] = $course_price_detail['USD']['discount'];
        $return_data['course_price']['currency'] = "$";
    }

  }

  if(isset($courseData['course_highlights']) && $courseData['course_highlights']){
    $return_data['course_highlights']=json_decode($courseData['course_highlights'],true);
  }

  if(isset($courseData['course_highlights']) && $courseData['course_highlights']){
    $return_data['course_highlights']=json_decode($courseData['course_highlights'],true);
  }

  if(isset($courseData['meta_keywords']) && $courseData['meta_keywords']){
    $return_data['meta_keywords']=json_decode($courseData['meta_keywords'],true);
  }

  return $return_data;
 }











?>