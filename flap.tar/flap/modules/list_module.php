<?php
function getCourseList($page='',$category=''){
    $category='';$subcategory='';
    $where='';
    if(isset($_REQUEST['category']) && !empty($_REQUEST['category'])){
        $category = $_REQUEST['category'];
        $where="AND kc.category_url ='$category' AND kc.parent_category_id='0'";
     }

     if(isset($_REQUEST['category']) && isset($_REQUEST['subcate'])){
        $subcategory = $_REQUEST['subcate'];
        $where="AND k.category_url ='$subcategory'";
     }


    $rowsPerPage=3;
    $pageNum=isset($_REQUEST['page'])?$_REQUEST['page']:"1";
    $offset = ($pageNum - 1) * $rowsPerPage;
    $num_of_record=0;

    $countQuery="SELECT count(*) as course_count FROM flapone_course AS c INNER JOIN flapone_category AS k ON c.category_id = k.category_id LEFT JOIN flapone_category AS kc ON k.parent_category_id = kc.category_id WHERE c.course_status='1' $where";
    $countSql = selectSqLQuery($countQuery);
    if(mysqli_num_rows($countSql) > 0){
        $course_data=array();
        $rows = mysqli_fetch_assoc($countSql);
        $num_of_record=$rows['course_count'];
    }

    $offset_auto=$num_of_record/$rowsPerPage;
    $offset_auto=floor($offset_auto);

    #print_r(array($offset_auto,$rowsPerPage,$num_of_record));die;

    $response_array=array();
    $return_data=array();
    $listQuery="SELECT 
    kc.meta_keywords AS parent_category_meta_keywords,
    kc.category_id AS parent_category_id,
    kc.category_name AS parent_category_name,
    kc.category_url AS parent_category_url,
    k.meta_keywords AS category_meta_keywords,
    k.category_id,
    k.category_name,
    k.category_url,
    c.course_id,
    c.course_name,
    c.course_url,
    c.course_overview
    FROM 
        flapone_course AS c
    INNER JOIN 
        flapone_category AS k ON c.category_id = k.category_id
    LEFT JOIN 
        flapone_category AS kc ON k.parent_category_id = kc.category_id
    WHERE c.course_status='1' $where
    LIMIT $offset,$rowsPerPage";
  
    $listSql = selectSqLQuery($listQuery);

    if(mysqli_num_rows($listSql) > 0){
            $course_data=array();$getmeta='0';
            while($rows = mysqli_fetch_assoc($listSql))  {
                $course_data['parent_category_id'] = $rows['parent_category_id'];
                $course_data['parent_category_name'] = $rows['parent_category_name'];
                $course_data['parent_category_url'] = $rows['parent_category_url'];
                $course_data['category_id'] = $rows['category_id'];
                $course_data['category_name'] = $rows['category_name'];
                $course_data['category_url'] = $rows['category_url'];
                $course_data['course_id'] = $rows['course_id'];
                $courseImage = getCourceImage($course_data['course_id']);
                $course_data['course_image'] = $courseImage;
                $course_data['course_name'] = $rows['course_name'];
                $course_data['course_url'] = BASEURL.$course_data['parent_category_url']."/".$rows['category_url']."/".$rows['course_url'];
                if($rows['course_overview']){
                  $course_data['course_desc'] = $rows['course_overview'];
                  $decode_course_desc = json_decode($course_data['course_desc'],true);
                  if(isset($decode_course_desc[0]['overview'])){
                   $course_data['course_desc'] = strip_tags($decode_course_desc[0]['overview']);
                  }
                }else{
                  $course_data['course_desc'] = "";   
                }

                $return_data[] = $course_data;
            }   
    } 


    $response_array['courses']=$return_data;
    $response_array['offset_auto']=$offset_auto;
    $response_array['row_per_page']=$rowsPerPage;
    
    return $response_array;
}



function getpageOtherData(){
    $return_data=array();
    $coverimage=array();
    $decode_pmeta_keywords='';$pagetitle='';$faq_type='';$cat_id='';
    if(isset($_REQUEST['category']) && isset($_REQUEST['subcate'])){
            $categoryData=getCategoryData($_REQUEST['category'],$_REQUEST['subcate']);
            if($categoryData['meta_keywords']){
             $decode_pmeta_keywords = json_decode($categoryData['meta_keywords'],true);
            }
            $pagetitle = $categoryData['category_name'];
            $page_status='1';
            $faq_type='category';
            $cat_id=$categoryData['category_id'];
            $coverimage=getPageWiseImageAll($cat_id,"category");
        
    }else if(isset($_REQUEST['category']) && !empty($_REQUEST['category'])){
            $categoryData=getCategoryData($_REQUEST['category'],"");
            if($categoryData['meta_keywords']){
             $decode_pmeta_keywords = json_decode($categoryData['meta_keywords'],true);
            }
            $pagetitle = $categoryData['category_name'];
            $page_status='1';
            $faq_type='category';
            $cat_id=$categoryData['category_id'];
            $coverimage=getPageWiseImageAll($cat_id,"category");
      
    }else  if(!isset($_REQUEST['category']) && !isset($_REQUEST['subcate'])){
            $pageData=getPageDetail('Courses');
            $decode_pmeta_keywords = json_decode($pageData['meta_keywords'],true);
            $pagetitle = $pageData['page_title'];
            $page_status=$pageData['page_status'];
            $faq_type='common';
            $coverimage=getPageWiseImageAll($pageData['page_id'],"pages");   
    }

    
    $return_data['page_status']=$page_status;
    $return_data['coverimage']=$coverimage['cover_image'];
    $return_data['faq_type']=$faq_type;
    $return_data['cat_id']=$cat_id;
    $return_data['meta_keywords']=$decode_pmeta_keywords;
    $return_data['page_title']=$pagetitle;
    $return_data['category']=isset($_REQUEST['category'])?$_REQUEST['category']:"";
 
    return $return_data;
}





function getCategoryData($parent_cat_url="",$cat_url=""){
    $return_data=array();

    if($parent_cat_url!='' && $cat_url!=''){
        $catQuery="SELECT T1.*  FROM flapone_category T1, flapone_category T2 WHERE T1.parent_category_id=T2.category_id  AND  T1.category_url='$cat_url' LIMIT 1";
    }

    else if($parent_cat_url!=''){
        $catQuery="SELECT * from flapone_category where category_url='$parent_cat_url'";
        
    }

    #echo $catQuery;die;

    $catSql = selectSqLQuery($catQuery);
    if(mysqli_num_rows($catSql) > 0){
            $rows = mysqli_fetch_assoc($catSql);
            $return_data = $rows;
       }
    return $return_data;
 }










?>