<?php
function getParentCategoryList(){
    $response_array=array();
    $return_data=array();
    $categoryQuery="SELECT category_id,category_name,category_url,parent_category_id FROM  flapone_category WHERE parent_category_id='0'";
    
    $categorySql = selectSqLQuery($categoryQuery);

    if(mysqli_num_rows($categorySql) > 0){
            while($rows = mysqli_fetch_assoc($categorySql))  {
                $rows['full_category_url'] = BASEURL.$rows['category_url'];
                $response_array[] = $rows;
            }   
    } 

    return $response_array;
 }

 function getPageDetail($page){
    $response_array=array();
    $return_data=array();
    $pageDetailQuery="SELECT * FROM  flapone_pages where page_status='1' AND page_name='$page'";
    
    $pageDetailSql = selectSqLQuery($pageDetailQuery);
    if(mysqli_num_rows($pageDetailSql) > 0){
            $rows = mysqli_fetch_assoc($pageDetailSql);
                $response_array = $rows;  
    } 

    return $response_array;
}

function getFaqData($faq_type='',$cat_id=''){
    $return_data=array();
    $faq_qry = $cat_qry='';

    if($faq_type){
        $faq_qry='AND T2.faq_type LIKE "%'.$faq_type.'%"';
    }
    
    if($cat_id){
        $cat_qry="AND T2.cat_id IN ('$cat_id','0')";
    }

    $faqQuery="SELECT T1.question_answer_text as answer,T2.question_answer_text as question FROM flapone_faq T1, flapone_faq T2 WHERE T1.quetion_id=T2.id  AND T1.status='1' $faq_qry $cat_qry  ORDER BY T2.orderby ASC LIMIT 10";

    $faqSql = selectSqLQuery($faqQuery);
    if(mysqli_num_rows($faqSql) > 0){
            $faq_array = array();
            while($rows = mysqli_fetch_assoc($faqSql)){
             $faq_array['question'] = $rows['question'];
             $faq_array['answer'] = $rows['answer'];
             $return_data[]=$faq_array;
          }
        }
    return $return_data;
 }



 
function getPages(){
    $response_array=array();
    $return_data=array();
    $pagesQuery="SELECT * FROM  flapone_pages where page_status='1' ";
    
    $pagesSql = selectSqLQuery($pagesQuery);

    if(mysqli_num_rows($pagesSql) > 0){
            while($rows = mysqli_fetch_assoc($pagesSql))  {
                $response_array[] = $rows;
            }   
    } 

    return $response_array;
}
function getCourceImage($image_id){
    $image=DEFAULT_IMAGE;
    $imgQuery="SELECT image_url from flapone_images where type='course' AND cover_image='1' AND fk_id=$image_id";
    $imgSql = selectSqLQuery($imgQuery);
    if(mysqli_num_rows($imgSql) > 0){
            $rows = mysqli_fetch_assoc($imgSql);
            $image = $rows['image_url'];
       }
    return $image;
 }

 function getCatDeatil($cat_id){
    $return_data = array();
    $catQuery="SELECT * from flapone_category where category_id='$cat_id' LIMIT 1";
   
    $catSql = selectSqLQuery($catQuery);
    if(mysqli_num_rows($catSql) > 0){
            $rows = mysqli_fetch_assoc($catSql);
            $return_data = $rows;
       }
  
    return $return_data;
  
  }

?>
