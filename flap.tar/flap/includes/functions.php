<?php

function selectSqLQuery($query) {
    global $conn;
    if(!empty($query)){
        $result = mysqli_query($conn, $query);
    }
    return $result;
}

function queryprocess($query) {
    global $conn;
    $result = false;
    if (!empty($query)) {
        $queryResult = mysqli_query($conn, $query);
        if ($queryResult !== false) {
            if (strpos(strtoupper(trim($query)), 'INSERT') === 0) {
                $result = mysqli_insert_id($conn);
            } elseif (strpos(strtoupper(trim($query)), 'SELECT') === 0) {
                $result = $queryResult;
            } else {
                $result = true;
            }
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
    return $result;
}


function CheckSelectSQLQuery($query, $action = '') {
    global $conn;
    if(!empty($query)){
        $result = mysqli_query($conn, $query);
        if($action != 'Insert'){
            if(mysqli_num_rows($result) > 0){
                
                if(mysqli_num_rows($result) > 1){
                    while($rows = mysqli_fetch_assoc($result))  {
                        $record[] = $rows;
                    } 
                } else {
                    $record = mysqli_fetch_assoc($result);
                }
                
            } else {
                $record = 0;
            }
        } else {
            $record = mysqli_insert_id($conn);
        }
    }

    return $record;
}


function getLocationData($location_show=''){
    $return_data=array();
    $location_show_qry ='';
    if($location_show){
        $location_show_qry="AND location_show ='$location_show'";
    }
    $faqQuery="SELECT * FROM flapone_location  WHERE location_status='1' $location_show_qry order by orderby ASC";
    $faqSql = selectSqLQuery($faqQuery);
    if(mysqli_num_rows($faqSql) > 0){
            while($rows = mysqli_fetch_assoc($faqSql)){
             $return_data[]=$rows;
          }
        }
    return $return_data;
 }

 function getPageWiseImageAll($fk_id,$type){
    $return_data=array();
    $type_qry = $fkid_qry = $cover_qry ='';

    if($type){
        $type_qry="AND type ='$type'";
    }
    
    if($fk_id){
        $fkid_qry="AND fk_id ='$fk_id'";
    }
    $cover_qry="order by orderby asc";
    
    $imgQuery="SELECT * from flapone_images where  image_status='1' $type_qry $fkid_qry $cover_qry";
    $allimage = array();
    $imgSql = selectSqLQuery($imgQuery);
    if(mysqli_num_rows($imgSql) > 0){
        while($rows = mysqli_fetch_assoc($imgSql)){
            if($rows['cover_image']){
                $return_data['cover_image'] = $rows['image_url'];
            }
            else{
                $temp = array();
                if($rows['dest_type']=='video'){
                    $temp['url'] =  $rows['video_url'];
                }
                else{
                    $temp['url'] =  $rows['image_url'];
                }
                $temp['type'] =  $rows['dest_type'];
                $return_data['allimage'][] = $temp;
            }
        }
    }
    if($return_data['cover_image']==''){
        $return_data['cover_image'] = COVER_IMAGE;
    }
    return $return_data;
 }
 function getourAward($numrecord=0){
    if($numrecord>0){
    $awarddata = "SELECT * from flapone_articles where status='1' and type='main' and article_type='awards' limit $numrecord";
    }
    else{
        $awarddata = "SELECT * from flapone_articles where status='1' and type='main' and article_type='awards'";
    }
    $awardRecords = array();
    $awardq = selectSqLQuery($awarddata);

    if (mysqli_num_rows($awardq) > 0) {
        while ($rows = mysqli_fetch_assoc($awardq)) {
            $id = $rows['id'];
            $imgQuery = "SELECT * from flapone_images where image_status='1' and fk_id=$id and type='article' limit 1";
            $imgSql = selectSqLQuery($imgQuery);

            if (mysqli_num_rows($imgSql) > 0) {
                $row_img = mysqli_fetch_assoc($imgSql);
                $rows['image_url'] = $row_img['image_url'];
            } else {
                $rows['image_url'] = COVER_IMAGE;
            }

            $awardRecords[] = $rows;
        }
    }
    return $awardRecords;
}
function getourTeam($type=[],$ids=[]){
    if(!empty($type)){
        $implode = implode(",",$type);
        $sub_user = "and sub_user in(".$implode.") ";
        $ourteam = "select * from flapone_user , flapone_employee,flapone_user_rolls where flapone_user.user_id =  flapone_employee.fk_user_id and flapone_employee.roll_id=flapone_user_rolls.id  and user_type='employee' $sub_user order by sub_user";
    }
    else if(!empty($ids)){
        $implode = implode(",",$ids);
        $sub_user = "and flapone_user.user_id in(".$implode.") ";
        $ourteam = "select * from flapone_user , flapone_employee,flapone_user_rolls where flapone_user.user_id =  flapone_employee.fk_user_id and flapone_employee.roll_id=flapone_user_rolls.id  and user_type='employee' $sub_user order by sub_user";

    }
    else{
        $ourteam = "select * from flapone_user , flapone_employee,flapone_user_rolls where flapone_user.user_id =  flapone_employee.fk_user_id and flapone_employee.roll_id=flapone_user_rolls.id  and user_type='employee' order by sub_user";
    }
    $ourteamRecord = array();
    $ourteamres = selectSqLQuery($ourteam);

    if (mysqli_num_rows($ourteamres) > 0) {
        while ($rows = mysqli_fetch_assoc($ourteamres)) {
            if($rows['user_image']){
                $rows['user_image'] = MEDIA_URL."images/team/".$rows['user_image'];
            }
            if($rows['social_media_url']){
                $rows['social_media_url'] = json_decode($rows['social_media_url'],true);
            }
            $ourteamRecord[] = $rows;
        }
    }
    //print_r($ourteamRecord);die;
    return $ourteamRecord;
}
function getSimilarCourseList($categoryData,$cat_id,$course_id){
    $response_array=array();
    $wherecat = $orderby = $wherecourse ='';
  
    if(isset($cat_id) && !empty($cat_id) && $categoryData){
      $parent_cat_id=$categoryData['parent_category_id'];
      $wherecat="AND kc.category_id ='$parent_cat_id' AND kc.parent_category_id='0'";
      $orderby="ORDER BY category_id ASC";
    }
  
    if(isset($course_id) && !empty($course_id)){
      $wherecourse="AND c.course_id!='$course_id'";
    }
  
    
    $courseListQuery="SELECT kc.category_id AS parent_category_id, kc.category_name AS parent_category_name, kc.category_url AS parent_category_url, k.category_id, k.category_name, k.category_url, c.course_id, c.course_name, c.course_url, c.course_overview FROM flapone_course AS c INNER JOIN flapone_category AS k ON c.category_id = k.category_id LEFT JOIN flapone_category AS kc ON k.parent_category_id = kc.category_id WHERE c.course_status='1' $wherecat $wherecourse $orderby LIMIT 6";
  
    $courseListSql = selectSqLQuery($courseListQuery);
  
    if(mysqli_num_rows($courseListSql) > 0){
            $course_data=array();
            while($rows = mysqli_fetch_assoc($courseListSql))  {
                $course_data['parent_category_id'] = $rows['parent_category_id'];
                $course_data['parent_category_name'] = $rows['parent_category_name'];
                $course_data['parent_category_url'] = $rows['parent_category_url'];
                $course_data['category_id'] = $rows['category_id'];
                $course_data['category_name'] = $rows['category_name'];
                $course_data['category_url'] = $rows['category_url'];
                $course_data['course_id'] = $rows['course_id'];
                $courseImage = getCourceImage($course_data['course_id']);
                $course_data['course_image'] = $courseImage;
                $course_data['course_name'] = $rows['course_name'];
                $course_data['course_url'] = BASEURL.$course_data['parent_category_url']."/".$rows['category_url']."/".$rows['course_url'];
                if($rows['course_overview']){
                  $course_data['course_desc'] = $rows['course_overview'];
                  $decode_course_desc = json_decode($course_data['course_desc'],true);
                  if(isset($decode_course_desc[0]['overview'])){
                   $course_data['course_desc'] = strip_tags($decode_course_desc[0]['overview']);
                  }
                }else{
                  $course_data['course_desc'] = "";   
                }
  
                $return_data[] = $course_data;
            }   
    } 
  
  
    $response_array=$return_data;
    
    return $response_array;
  }

function getArticleData($num=0,$type=''){
    $return_data = array();
    if($type){
        $limitq ='';
        if($num>0){
            $limitq =" LIMIT $num";
        }
        $query = "SELECT *  FROM flapone_articles WHERE status = '1' AND article_type = '".$type."' and type='main' $limitq";
        $data = queryprocess($query);
        while($datar = mysqli_fetch_assoc($data)){
            $id = $datar['id'];
            $imgQuery = "SELECT * from flapone_images where image_status='1' and fk_id=$id and type='article' limit 1";
            $imgSql = selectSqLQuery($imgQuery);

            if (mysqli_num_rows($imgSql) > 0) {
                $row_img = mysqli_fetch_assoc($imgSql);
                $datar['image_url'] = $row_img['image_url'];
            } else {
                $datar['image_url'] = COVER_IMAGE;
            }
            $datar['article_url']  = BASEURL."blog/".$datar['article_url'];
           $return_data[]  = $datar;
        }
    }
    return $return_data;
}

function getReviewTestimotional($num=0){
    $return_data = array();
    $numq = "";
    if($num>0){
        $numq = "LIMIT $num";
    }
    $reviewquery = "SELECT *  FROM flapoone_testimonial WHERE type = 'public' AND status = '1' order by update_date desc $numq";
    $checkres = queryprocess($reviewquery);
    while($rows = mysqli_fetch_assoc($checkres)){
        $id = $rows['flapone_userid'];
        $user_data = queryprocess("select * from flapone_user where user_id=$id");
        $userd = mysqli_fetch_assoc($user_data);
        $rows['user_name'] = !empty($userd['name'])?$userd['name']:"User";
        $rows['review_description'] = trim($rows['review_description']);
        $rows['review_title'] = trim($rows['review_title']);
        $return_data[] = $rows;
    }
    return $return_data;
}

?>
