<?php 

date_default_timezone_set("Asia/Calcutta");
define('DIR_SETUP_PATH', '/home3/indiamart/public_html/flapone/');

require_once DIR_SETUP_PATH.'includes/con.php';

define('MEDIA_URL', 'http://media.flapone.noida/');
define('COVER_IMAGE', 'https://templatekit.tokomoo.com/aviationkit/wp-content/uploads/sites/106/2022/09/hero-team.jpg');
define('DEFAULT_IMAGE', 'https://i.postimg.cc/4yrx4Fck/little-drone-filming-videos-stills-flying-air.jpg');
//=============================Old===========================
define('IMAGE_URL', BASEURL.'assets/images/');
define('ENQUIR_NOW_URL','https://enquiry.flapone.com/');
define('ENQUIRY_IMAGE_URL', BASEURL.'assets/images/enquiry/');



?>