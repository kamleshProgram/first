<?php
require_once '/home3/indiamart/public_html/flapone/includes/config.php';
require_once ('/home3/indiamart/public_html/flapone/includes/functions.php');
$full_path_to_public_program = "/home/indiamart/public_html/flapone";
require($full_path_to_public_program."/config/TplLoad.php");
require_once ('/home/indiamart/public_html/flapone/modules/header.php');
$smarty_obj = new TplLoad();

$pageData=getPageDetail('Contact Us');

$decode_pmeta_keywords = json_decode($pageData['meta_keywords'],true);
$pageDataContent = json_decode($pageData['page_descriprion'],true);

$getaward = getourAward(6);
$faqList=getFaqData('common','');
$locationList=getLocationData('footer');
$parentCategoryList = getParentCategoryList();

$smarty_obj->assign('BASEURL', BASEURL);
$smarty_obj->assign('MEDIA_URL', MEDIA_URL);
$smarty_obj->assign('page', "contactus");

$smarty_obj->assign("pagedatacontent",$pageDataContent);
$smarty_obj->assign('pagetitle', $pageData['page_title']);
$smarty_obj->assign("pagestatus",$pageData['page_status']);
$smarty_obj->assign('breadcrumbData', array(array('title'=>$pageData['page_title'])));

$smarty_obj->assign("meta_title",$decode_pmeta_keywords[0]['meta_title']);
$smarty_obj->assign("meta_description",$decode_pmeta_keywords[1]['meta_desc']);
$smarty_obj->assign("meta_keywords",$decode_pmeta_keywords[2]['meta_keywords']);

$smarty_obj->assign('awarddata', $getaward);
$smarty_obj->assign('faqlist', $faqList);
$smarty_obj->assign('parentCategoryList', $parentCategoryList);

$smarty_obj->display('common/header.tpl');
$smarty_obj->display('contact-us.tpl');
$smarty_obj->assign('locationlist', $locationList);
$smarty_obj->display('common/footer.tpl');

?>
