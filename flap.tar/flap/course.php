<?php
require_once ('/home3/indiamart/public_html/flapone/includes/config.php');
require_once ('/home3/indiamart/public_html/flapone/includes/functions.php');
require_once '/home/indiamart/public_html/flapone/modules/course_module.php';
$full_path_to_public_program = "/home/indiamart/public_html/flapone";
require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();
require_once ('/home/indiamart/public_html/flapone/modules/header.php');


$parentCategoryList = getParentCategoryList();

$courseData=checkCourseUrl();

$courseDetailData = getCourseDetail($courseData);

$courseImages=getPageWiseImageAll($courseData['course_id'],"course");

$gallaryImages=getPageWiseImageAll("","gallary");

$categoryData=getCatDeatil($courseData['category_id']);

$breadcrumbData = getBreadcrumbData($categoryData,$courseData);

$similarCourseList=getSimilarCourseList($categoryData,$courseData['category_id'],$courseData['course_id']);

$faqList=getFaqData('course',$courseData['course_id']);
$locationList=getLocationData('footer');

$teacherIds = getTeacherByCourse($courseData['course_id']);

$ourTeam = getourTeam("",$teacherIds);

$getaward = getourAward(6);

$pageOtherData=getpageOtherData($courseData);

$smarty_obj->assign('BASEURL', BASEURL);
$smarty_obj->assign('MEDIA_URL', MEDIA_URL);
$smarty_obj->assign('page', "course_detail");
$smarty_obj->assign('coursebg', "");

if(!empty($pageOtherData['meta_keywords'])){
    $smarty_obj->assign("meta_title",isset($pageOtherData['meta_keywords'][0]['meta_title'])?$pageOtherData['meta_keywords'][0]['meta_title']:"");
    $smarty_obj->assign("meta_description",isset($pageOtherData['meta_keywords'][1]['meta_desc'])?$pageOtherData['meta_keywords'][1]['meta_desc']:"");
    $smarty_obj->assign("meta_keywords",isset($pageOtherData['meta_keywords'][2]['meta_keywords'])?$pageOtherData['meta_keywords'][2]['meta_keywords']:"");
    }

$smarty_obj->assign('pagetitle', $courseData['course_name']);
$smarty_obj->assign("coverimage",$courseImages['cover_image']);
$smarty_obj->assign("pagestatus",$courseData['course_status']);
$smarty_obj->assign("sliderimage",$courseImages['allimage']);


$smarty_obj->assign('breadcrumbData', $breadcrumbData);
$smarty_obj->assign('parentCategoryList', $parentCategoryList);
$smarty_obj->assign('faqlist', $faqList);
$smarty_obj->assign('locationlist', $locationList);
$smarty_obj->assign('courseDetail', $courseDetailData);
$smarty_obj->assign('courselist', $similarCourseList);
$smarty_obj->assign('gallayimages', $gallaryImages['allimage']);
$smarty_obj->assign('awarddata', $getaward);
$smarty_obj->assign('ourteam', array("title"=>"TECHING STAFF","heading"=>"Our Techer's","data"=>$ourTeam));

$smarty_obj->display('common/header.tpl');
$smarty_obj->display('course_detail.tpl');
$smarty_obj->display('common/footer.tpl');

?>