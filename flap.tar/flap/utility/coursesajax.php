<?php 

require_once ('/home3/indiamart/public_html/flapone/includes/config.php');
require_once ('/home3/indiamart/public_html/flapone/includes/functions.php');
require_once ('/home3/indiamart/public_html/flapone/modules/list_module.php');

$full_path_to_public_program = "/home/indiamart/public_html/flapone";

require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();

  require_once ('/home/indiamart/public_html/flapone/modules/header.php');

  $page=$_REQUEST['page'];
  $category=$_REQUEST['category'];
  $courseList=array();

  $smarty_obj->assign('BASEURL', BASEURL);
  $smarty_obj->assign('MEDIA_URL', MEDIA_URL);
  
  $courseList=getCourseList($page,$category);

  $smarty_obj->assign('courselist', $courseList['courses']);

  $smarty_obj->display('components/course_listing.tpl');
        
       
?>
