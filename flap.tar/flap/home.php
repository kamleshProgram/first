<?php
require_once '/home3/indiamart/public_html/flapone/includes/config.php';
require_once ('/home3/indiamart/public_html/flapone/includes/functions.php');
$full_path_to_public_program = "/home/indiamart/public_html/flapone";
require($full_path_to_public_program."/config/TplLoad.php");
require_once ('/home/indiamart/public_html/flapone/modules/header.php');
$smarty_obj = new TplLoad();
$return_image  = getPageWiseImageAll(1,'pages');
$locationList=getLocationData('footer');
$parentCategoryList = getParentCategoryList();
$faqList=getFaqData('common','');
$getaward = getourAward(6);
$courseList = getSimilarCourseList('','','');

$pageData=getPageDetail('home');
$return_image  = getPageWiseImageAll(15,'pages');

$decode_pmeta_keywords = json_decode($pageData['meta_keywords'],true);
$pageDataContent = json_decode($pageData['page_descriprion'],true);


$gallaryImages=getPageWiseImageAll("","gallary");
$articleresult=getArticleData(5,"blog");
$testimotional = getReviewTestimotional(6);

$smarty_obj->assign('BASEURL', BASEURL);
$smarty_obj->assign('MEDIA_URL', MEDIA_URL);
$smarty_obj->assign('page', "home");
$smarty_obj->assign('coursebg', "dark");
$smarty_obj->assign('enquir_url',ENQUIR_NOW_URL);

$smarty_obj->assign("coverimage",$return_image['cover_image']);
$smarty_obj->assign("allimage",$return_image['allimage']);
$smarty_obj->assign("pagedatacontent",$pageDataContent);

$smarty_obj->assign('faqlist', $faqList);
$smarty_obj->assign('courselist', $courseList);
$smarty_obj->assign('faqheading', array("title"=>"Frequently Asked Questions","description"=>"Lorem ipsum dolor sit amet consectetur adipisicing elit. Non officia sapiente optio laboriosam aut modi?"));
$smarty_obj->assign('parentCategoryList', $parentCategoryList);
$smarty_obj->assign('testimotional', array("title"=>"TESTIMONIALS","subtitle"=>"Our Testimonials","data"=>$testimotional));
$smarty_obj->assign('awarddata', $getaward);
$smarty_obj->assign("meta_title",$decode_pmeta_keywords[0]['meta_title']);
$smarty_obj->assign("meta_description",$decode_pmeta_keywords[1]['meta_desc']);
$smarty_obj->assign("meta_keywords",$decode_pmeta_keywords[2]['meta_keywords']);
$smarty_obj->assign('gallayimages', $gallaryImages['allimage']);

$smarty_obj->assign('articleresult', array("title"=>"Our Programs","subtitle"=>"Blogs & Resources","viewallurl"=>BASEURL."blogs","data"=>$articleresult,"bgcolor"=>""));

$smarty_obj->display('common/header.tpl');
$smarty_obj->display('home.tpl');
$smarty_obj->assign('locationlist', $locationList);
$smarty_obj->display('common/footer.tpl');

?>