<?php
require_once '/home3/indiamart/public_html/flapone/includes/config.php';
require_once ('/home3/indiamart/public_html/flapone/includes/functions.php');
$full_path_to_public_program = "/home/indiamart/public_html/flapone";
require($full_path_to_public_program."/config/TplLoad.php");
$smarty_obj = new TplLoad();

require_once ('/home/indiamart/public_html/flapone/modules/header.php');

$parentCategoryList = getParentCategoryList();

$smarty_obj->assign('BASEURL', BASEURL);
$smarty_obj->assign('MEDIA_URL', MEDIA_URL);
$smarty_obj->assign('page', "blog");
$locationList=getLocationData('footer');

$smarty_obj->assign('parentCategoryList', $parentCategoryList);
$smarty_obj->assign('faqlist', $faqList);
$smarty_obj->assign('locationlist', $locationList);

$smarty_obj->display('common/header.tpl');
$smarty_obj->display('common/footer.tpl');

?>